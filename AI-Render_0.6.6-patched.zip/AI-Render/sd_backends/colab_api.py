import bpy
import base64
import re
import os
import requests
import math
import numpy as np
from .. import (
    config,
    operators,
    utils,
)

UPSCALE = 4
API_ENDPOINT = "api/generate"
API_VERSION = 5

# CORE FUNCTIONS:

def split_image(image, square_size, num_rows, num_cols):   
    # initialize a list to store the squares
    squares = []
    # split the image into squares
    for i in range(num_rows):
        for j in range(num_cols):
            start_row = i * square_size
            end_row = start_row + square_size
            start_col = j * square_size
            end_col = start_col + square_size
            square = image[start_row:end_row, start_col:end_col]
            (size_rows, size_cols) = square.shape[:2]
            square = np.pad(square, [(0, square_size - size_rows), (0, square_size - size_cols), (0, 0)], mode='constant')
            squares.append(square)
        
    return squares

def merge_squares(squares, square_size, num_rows, num_cols):
    # create an empty image with the correct size
    merged_image = np.zeros((num_rows*square_size, num_cols*square_size, 4), dtype=np.float64)
    # copy the squares into the merged image
    k = 0
    for i in range(num_rows):
        for j in range(num_cols):
            start_row = i * square_size
            end_row = start_row + square_size
            start_col = j * square_size
            end_col = start_col + square_size
            merged_image[start_row:end_row, start_col:end_col] = squares[k]
            k += 1
    
    return merged_image

def getImageData(image_path):
    # load the image
    image = bpy.data.images.load(image_path, check_existing=False)
    # get the image pixels as a NumPy array and reshape the pixels array to a 2D image
    data = np.array(image.pixels[:]).reshape((image.size[1], image.size[0], 4))
    bpy.data.images.remove(image) # we have the data, remove loaded image
    return data

def upscale_image(params, img_file, filename_prefix, sd_model, slice_size):
    # slice size
    params["width"] = slice_size
    params["height"] = slice_size
    # load the image
    image = getImageData(img_file.name)
    # get the dimensions of the image
    (rows, cols) = image.shape[:2]
    # calculate the number of rows and columns of squares
    num_rows = math.ceil(rows / slice_size)
    num_cols = math.ceil(cols / slice_size)
    # split the image into squares of size slice_size
    squares = split_image(image, slice_size, num_rows, num_cols)

    squares_upscaled = []
    for i, square in enumerate(squares, start=0):
        slice_name = "slice_" + str(i)
        slice_path = utils.create_temp_file(slice_name + "-")
        image_slice = bpy.data.images.new(slice_name, width=slice_size, height=slice_size)
        image_slice.pixels = np.concatenate(square, axis=None).ravel().tolist()
        image_slice.filepath_raw = slice_path
        image_slice.file_format = 'PNG'
        image_slice.save()
        bpy.data.images.remove(image_slice)
        upscaled_image = open(slice_path, 'rb')
        upscaled_image_path = generate_image(params, upscaled_image, filename_prefix, sd_model)
        squares_upscaled.append(getImageData(upscaled_image_path))
        #cleanup
        if os.path.exists(slice_path):
            os.remove(slice_path)
        if os.path.exists(upscaled_image_path):
            os.remove(upscaled_image_path)
        
    # merge the squares back into an image
    merged_image = merge_squares(squares_upscaled, slice_size*UPSCALE, num_rows, num_cols)

    # create a new image in Blender and copy the pixels from the NumPy array to the Blender image
    output_file = utils.create_temp_file(filename_prefix + "-")
    merged_image_block = bpy.data.images.new(filename_prefix, width=num_cols*slice_size*UPSCALE, height=num_rows*slice_size*UPSCALE)
    merged_image_block.pixels = np.concatenate(merged_image, axis=None).ravel().tolist()
    merged_image_block.save_render(output_file)
    bpy.data.images.remove(merged_image_block)

    return output_file

def generate_image(params, img_file, filename_prefix, sd_model):
    # map the generic params to the specific ones for the Automatic1111 API
    map_params(params)
    params["mode"] = sd_model

    # add a base 64 encoded image to the params
    params["init_img"] = base64.b64encode(img_file.read()).decode()
    img_file.close()
    
    # create the headers
    headers = {
        "User-Agent": "Blender/" + bpy.app.version_string,
        "Accept": "*/*",
        "Content-Type": "application/json",
    }
     
    # prepare the server url
    server_url = utils.local_sd_url().rstrip("/").strip()
    server_url = server_url + "/" if not re.match(".*/$", server_url) else server_url
    server_url = re.sub("http://", "https://", server_url)
    server_url = server_url + API_ENDPOINT

    # send the API request
    try:
        response = requests.post(server_url, json=params, headers=headers, timeout=utils.local_sd_timeout())
    except requests.exceptions.ConnectionError:
        return operators.handle_error(f"The local Stable Diffusion server couldn't be found. It's either not running, or it's running at a different location than what you specified in the add-on preferences. [Get help]({config.HELP_WITH_LOCAL_INSTALLATION_URL})", "local_server_not_found")
    except requests.exceptions.MissingSchema:
        return operators.handle_error(f"The url for your local Stable Diffusion server is invalid. Please set it correctly in the add-on preferences. [Get help]({config.HELP_WITH_LOCAL_INSTALLATION_URL})", "local_server_url_invalid")
    except requests.exceptions.ReadTimeout:
        return operators.handle_error("The local Stable Diffusion server timed out. Set a longer timeout in AI Render preferences, or use a smaller image size.", "timeout")

    # handle the response
    if response.status_code == 200:
        return handle_api_success(response, filename_prefix)
    else:
        return handle_api_error(response)

def send_to_api(params, img_file, filename_prefix, sd_model):
    # upscale slices the image
    if sd_model == "MODE_UPSCALING":
        return upscale_image(params, img_file, filename_prefix, sd_model, 256 if int(params["width"]) >= 256 and int(params["height"]) >= 256 else 128)
    else: 
        return generate_image(params, img_file, filename_prefix, sd_model)

def handle_api_success(response, filename_prefix):
    # ensure we have the type of response we are expecting
    try:
        response_obj = response.json()
        base64_img = response_obj["images"][0]["image"]
    except:
        print("Automatic1111 response content: ")
        print(response.content)
        return operators.handle_error("Received an unexpected response from the Automatic1111 Stable Diffusion server.", "unexpected_response")

    # create a temp file
    try:
        output_file = utils.create_temp_file(filename_prefix + "-")
    except:
        return operators.handle_error("Couldn't create a temp file to save image.", "temp_file")

    # decode base64 image
    try:
        img_binary = base64.b64decode(base64_img)
    except:
        return operators.handle_error("Couldn't decode base64 image from the Automatic1111 Stable Diffusion server.", "base64_decode")

    # save the image to the temp file
    try:
        with open(output_file, 'wb') as file:
            file.write(img_binary)
    except:
        return operators.handle_error("Couldn't write to temp file.", "temp_file_write")


    # return the temp file
    return output_file


def handle_api_error(response):
    if response.status_code in [403, 404]:
        return operators.handle_error("It looks like the web server this add-on relies on is missing. It's possible this is temporary, and you can try again later.")
    elif response.status_code == 405:
        return operators.handle_error("Plugin and stable-diffusion server don't match. Please update the plugin. If the error still occurs, please reopen the colab notebook.")
    elif response.status_code == 406:
        return operators.handle_error("Mode is not supported on used checkpoint running on Colab notebook.")
    # handle all other errors
    return operators.handle_error(f"An unknown error occurred. Code: {str(response.status_code)}")
# PRIVATE SUPPORT FUNCTIONS:

def map_params(params):
    params["init_strength"] = params["image_similarity"]
    params["prompt_strength"] = params["cfg_scale"]
    params["image_count"] = 1
    params["api_version"] = API_VERSION


# PUBLIC SUPPORT FUNCTIONS:

def get_samplers():
    # NOTE: Keep the number values (fourth item in the tuples) in sync with DreamStudio's
    # values (in stability_api.py). These act like an internal unique ID for Blender
    # to use when switching between the lists.
    return [
        ('Euler', 'Euler', '', 10),
        ('Euler a', 'Euler a', '', 20),
        ('Heun', 'Heun', '', 30),
        ('DPM2', 'DPM2', '', 40),
        ('DPM2 a', 'DPM2 a', '', 50),
        ('LMS', 'LMS', '', 60),
        ('DPM fast', 'DPM fast', '', 70),
        ('DPM adaptive', 'DPM adaptive', '', 80),
        ('DPM++ 2S a Karras', 'DPM++ 2S a Karras', '', 90),
        ('DPM++ 2M Karras', 'DPM++ 2M Karras', '', 100),
        ('DPM++ 2S a', 'DPM++ 2S a', '', 110),
        ('DPM++ 2M', 'DPM++ 2M', '', 120),
        ('PLMS', 'PLMS', '', 200),
        ('DDIM', 'DDIM', '', 210),
    ]


def default_sampler():
    return 'LMS'


def get_image_format():
    return 'PNG'


def supports_negative_prompts():
    return False


def supports_choosing_model():
    return True


def max_image_size():
    return 2048 * 2048


def get_models():
    return [
        ('MODE_TEXT2IMG', 'txt2img', '', 10),
        ('MODE_IMG2IMG', 'img2img', '', 20),
        ('MODE_INPAINTING', 'inpaint', '', 30),
        ('MODE_UPSCALING', 'upsclate', '', 40),
    ]


def default_model():
    return 'MODE_IMG2IMG'
